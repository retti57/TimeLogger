from setuptools import setup, find_packages

setup(
    name='spiderpoints',
    version='0.0.12',
    packages=find_packages(exclude="tests"),
    description='Biblioteka do generowania punktów na podstawie współrzędnych, ilości powtórzeń i odległości.',
    long_description=open('README.md').read(),
    install_requires=[
        "geopy==2.4.1",
        "gpxpy==1.6.2",
        "simplekml==1.3.6"],
    url='https://github.com/retti57/GridOfPoints',
    author='Czajas',
    author_email='docz9856@wp.pl'
)
